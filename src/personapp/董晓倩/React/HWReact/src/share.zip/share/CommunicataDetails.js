// import React, { Component } from 'react'
// import { NavBar, List, InputItem, SearchBar, WingBlank, SegmentedControl } from 'antd-mobile';
// import { HashRouter as Router, Route, Link } from 'react-router-dom';
// import axios from 'axios'
// import { createForm } from 'rc-form';
// class CommunicataDetails extends Component {
//     componentDidMount() {
//         // this.autoFocusInst.focus();
//     }
//     handleClick = () => {
//         this.inputRef.focus();
//     }
//     constructor() {
//         super();
//         this.state = {
//             color1: true,
//             color2: true,
//             color3: true,
//             color4: true,
//             // data:[]
//         }
//     }
//     //   componentDidMount() {
//     //     console.log(this.state.data);
//     //     var id =this.props.match.params.id;
//     //     console.log(this.props)
//     //     console.log(id)
//     //     let url = `http://localhost:3005/learn/list`+id;
//     //     axios(url)
//     //         .then((res) => {
//     //           console.log(res.data)
//     //           console.log(res.data.learnList)
//     //             this.setState({
//     //               data: res.data.learnList[id-1]                 
//     //             })
//     //         })
//     //   }

//     changeColor1 = () => {
//         this.setState({
//             color1: !this.state.color1,
//         })
//     }
//     render() {
//         const { getFieldProps } = this.props.form;
//         let Zan1 = {
//             color: this.state.color1 ? '#000' : 'red',
//             fontSize: "3.2vh",
//             marginLeft: '11vw'
//         }
//         return (
//             <div>
//                 <NavBar style={{ backgroundColor: '#37376F', color: '#fff', position: 'sticky ', top: '0', zIndex: 10, textAlign: 'center' }}
//                     leftContent={[
//                         <Link to="/StudyCommunicate"><span style={{ fontSize: '17px', color: 'white' }} className="iconfont icon-ico_leftarrow"></span></Link>
//                     ]}>
//                     动态详情</NavBar>


//                 {/* <div style={{ width: "96vw", paddingBottom: "1vh", backgroundColor: "#fff", borderRadius: "2vh", margin: "2vw" }}>
//                                 <div style={{ height: "10vh", width: "90vw" }}>
//                                     <img src={(`studyCommunicate/1.jpg`)} style={{ height: "8vh", width: "8vh", borderRadius: "50%", margin: "1vh", float: "left" }}></img>
//                                     <div style={{ height: "8vh", width: "60vw", float: "left" }}>
//                                         <p style={{ margin: "2vh 0 0 2vh", fontSize: "2vh", float: "left" }}>{this.state.data.name}</p>
//                                         <p style={{ fontSize: "1vh", float: "left", margin: "6vh 0 0 -9vh" }}>{this.state.data.time}</p>
//                                     </div>
//                                 </div>
//                                 <div style={{ width: "90vw", margin: "3vw" }}>
//                                     <span>
//                                         {this.state.data.content}
//                                     </span>
//                                     <hr></hr>
//                                     <span className="iconfont icon-zhuanfa" style={{ fontSize: "4vw", margin: "0 12vw 0 13vw" }}>
//                                     </span>

//                                         <span className="iconfont icon-pinglun" style={{ fontSize: "6vw", margin: "0 12vw 0 13vw" }}>
//                                         </span>
//                                     <span className="iconfont icon-dianzan">
//                                     </span>
//                                 </div>
//                             </div> */}
//                 <div style={{ width: "96vw", paddingBottom: "2vh", backgroundColor: "#fff", borderRadius: "2vh", margin: "2vw" }}>
//                     <div style={{ height: "10vh", width: "90vw" }}>
//                         <img src={(`studyCommunicate/1.jpg`)} style={{ height: "8vh", width: "8vh", borderRadius: "50%", margin: "1vh", float: "left" }}></img>
//                         <div style={{ height: "8vh", width: "60vw", float: "left" }}>
//                             <p style={{ margin: "2vh 0 0 2vh", fontSize: "2.5vh", float: "left" }}>薄荷水加冰</p>
//                             <p style={{ fontSize: "1vh", float: "left", margin: "6vh 0 0 -9vh" }}>2018-4-05</p>
//                         </div>
//                     </div>
//                     <div style={{ width: "90vw", margin: "3vw", lineHeight: "3vh" }}>
//                         <span>
//                             大二就要分方向了，希望学长学姐可以给出一些建议，拜托了！
//                     </span>
//                     </div>
//                     <hr></hr>
//                     <div style={{ width: "96vw", margin: "2vw" }}>
//                         <p style={{ fontSize: "2.5vh" }}>评论</p>
//                         <div style={{ width: "94vw" }}>
//                             <div style={{ position: "relative", width: "5vh" }}>
//                                 <img src={(`studyCommunicate/2.jpg`)} style={{ height: "5vh", width: "5vh", borderRadius: "50%", margin: "1vh" }}></img>
//                             </div>
//                             <span style={{ position: "absolute", top: "38vh", left: "17vw" }}>柠檬</span>
//                             <span style={{ fontSize: "2vh", marginLeft: "2vw" }}>
//                                 主要分为五个方向
//                             </span>
//                             <hr></hr>
//                         </div>
//                         <div style={{ width: "94vw" }}>
//                             <div style={{ position: "relative", width: "5vh" }}>
//                                 <img src={(`studyCommunicate/2.jpg`)} style={{ height: "5vh", width: "5vh", borderRadius: "50%", margin: "1vh" }}></img>
//                             </div>
//                             <span style={{ position: "absolute", top: "50vh", left: "17vw" }}>柠檬</span>
//                             <span style={{ fontSize: "2vh", marginLeft: "2vw" }}>
//                                 主要分为五个方向
//                             </span>
//                             <hr></hr>
//                         </div>
//                     </div>
//                 </div>
//                 <div style={{ height: "5vh", width: "100vw", backgroundColor: "#fff", position: "fixed", top: "95%", lineHeight: "5vh" }}>
//                     <span className="iconfont icon-zhuanfa" style={{ fontSize: "4vw", margin: "0 12vw 0 13vw" }}>
//                     </span>
//                     <Link to="/Comment">
//                         <span className="iconfont icon-pinglun" style={{ fontSize: "6vw", margin: "0 12vw 0 13vw" }}>
//                         </span>
//                     </Link>
//                     <span style={Zan1} onClick={() => this.changeColor1()} className="iconfont icon-dianzan">
//                     </span>
//                 </div>
//             </div>
//         )
//     }
// }
// const CommunicataDetailsWrapper = createForm()(CommunicataDetails);
// export default CommunicataDetailsWrapper;
import React, { Component } from 'react';
import { NavBar, ActionSheet } from 'antd-mobile';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import axios from 'axios'
export default class Ping extends Component {
  constructor() {
    super();
    this.state = {
      data: [],
      todo: [],
      clicked2: true,
      lid: parseInt(''),
      name: '',
      content: '',
      yonghu:[],
      pic:[],

    };
  }
  dataList = [
    { url: 'cTTayShKtEIdQVEMuiWt', title: '朋友圈' },
    { url: 'umnHwvEgSyQtXlZjNJTt', title: '微信好友' },
    { url: 'SxpunpETIwdxNjcJamwB', title: 'QQ' },
  ].map(obj => ({
    icon: <img src={`https://gw.alipayobjects.com/zos/rmsportal/${obj.url}.png`} alt={obj.title} style={{ width: 36 }} />,
    title: obj.title,
  }));
  addItem = () => {
    console.log(1)
    let url = `http://localhost:3005/learntalk/add?lid=${this.state.lid}
    &name=${this.state.name}&content=${this.state.content}`;
    console.log(this.state.lid);
    console.log(this.state.name);
    console.log(this.state.content);


    axios(url)
      .then((res) => {
        console.log(7);
        if (res.data.ok) {
          console.log(1);

          alert(res.data.msg);
          window.location.reload();
        } else {
          console.log(2)

          alert(res.data.msg);
        }
      })

  }
  componentDidMount() {
    console.log(this.state.data);
    var id = this.props.match.params.id;
    console.log(this.props)
    console.log(id)
    let url = `http://localhost:3005/learn/list/` + id;
    let url1 = `http://localhost:3005/learntalk/list/`;
    axios(url)
      .then((res) => {
        this.setState({
          data: res.data
        })
        console.log(this.state.data)
        var brr = []
        this.state.data.map((item) => {
          if (item.id == id) {
            brr.push(item);
          }
          this.setState({
            data: brr
          })
        })
        console.log(this.state.data);
      })
    axios(url1)
      .then((res) => {
        this.setState({
          todo: res.data
        })
        var arr = [];
        this.state.todo.map((item) => {
          if (item.lid == id) {
            arr.push(item);
          }
          this.setState({
            todo: arr
          })
        })
      })
      let url3=`http://localhost:3005/users/getName`;
      axios(url3)
        .then((res)=>{
          this.setState({
            name:res.data.name
          })
        })
       
      let url4= `http://localhost:3005/users/list`;
      axios(url4)
      .then((res)=>{
        for (var i = 0; i < res.data.length; i++) {
          res.data[i].pic = "http://localhost:3005" + res.data[i].pic
          
        }
        this.setState({
          yonghu:res.data
        })
        console.log(this.state.yonghu)
        var qrr=[]
        var a=0;
        console.log(this.state.data)

        console.log(this.state.data[0].name)
        console.log(this.state.yonghu[0].name)
        for(var i=0;i<this.state.data.length;i++){
          for(var j=0;j<this.state.yonghu.length;j++){
            if(this.state.data[i].name == this.state.yonghu[j].name){
              console.log("等")
              a=this.state.yonghu[j].pic;
              break;
            }
            else{
              a=0;
            }
            console.log(a);

          }
          if(a!=0){
            console.log(a);

            qrr.push(a)
          }
        }
        this.setState({
          pic:qrr
        })
        console.log(this.state.qrr)
        console.log(this.state.yonghu)//usersst
         console.log(this.state.name)
       
      })
  }
  getContent = (e) => {
    this.setState({
      lid: this.props.match.params.id,
      content: e.target.value,
    })
    console.log(this.state.lid);
    console.log(this.props.match.params.id);
  }
  changeColor() {
    this.setState({
      clicked2: !this.state.clicked2
    })
  }
  render() {
    return (
      <div style={{ position: 'relative' }}>
        <NavBar
          style={{ backgroundColor: '#37376F', color: '#fff', position: 'fixed ', width: "100vw", top: 0, zIndex: 18, textAlign: 'center', height: '7vh' }}
          leftContent={[
            <Link to="/StudyCommunicate"><span style={{ fontSize: '17px', color: 'white' }} className="iconfont icon-ico_leftarrow"></span></Link>
          ]}
        >
          <span>评论</span>
        </NavBar>
        {/* {
              this.state.data.map((item, idx) =>
                <div style={{height: '20vh',background: '#fff', color: 'black' }}>
                  <div style={{ float: "left" }}>
                    <img src={(`studyCommunicate/1.jpg`)} style={{ height: '7vh', width: '12vw', borderRadius: '50%', marginLeft: 15, marginTop: 9 }} />
                  </div>
                  <div>
                  </div>
                  <p style={{ marginLeft: 75, fontSize: '2.5vh', lineHeight: 2.5, marginTop: 6 }}>{item.name}</p>
                  <div style={{ marginLeft: 75, color: 'gray', fontSize: '2vw', marginTop: "-5vw" }}>{item.time}</div>
                  <Link to={`/aboutyouknow/${item.id}`}>
                    <p style={{ marginLeft: 25, color: 'black', marginTop: 20,fontSize:17 }}>{item.content}</p>
                  </Link>

                </div>)} */}
        <div style={{ marginTop: "7vh" }}>
          {
            this.state.data.map((item,idx) => (
              <div style={{ width: "96vw", paddingBottom: "1vh", backgroundColor: "#fff", borderRadius: "2vh", margin: "2vw" }}>
                <div style={{ height: "10vh", width: "90vw" }}>
                  <img src={this.state.pic[idx]} style={{ height: "8vh", width: "8vh", borderRadius: "50%", margin: "1vh", float: "left" }}></img>
                  <div style={{ height: "8vh", width: "60vw", float: "left" }}>
                    <p style={{ margin: "2vh 0 0 6vh", fontSize: "2vh", float: "left" }}>{item.name}</p>
                    <p style={{ fontSize: "1vh", float: "left", margin: "6vh 0 0 -6vh" }}>{item.time}</p>
                  </div>
                </div>
                <div style={{ width: "90vw", margin: "3vw" }}>
                  <span>
                    {item.content}
                  </span>
                  {/* <hr></hr>
                                    <span className="iconfont icon-zhuanfa" style={{ fontSize: "4vw", margin: "0 12vw 0 13vw" }}>
                                    </span>
                                    <Link to={`/CommunicataDetails/${item.id}`}>
                                        <span className="iconfont icon-pinglun" style={{ fontSize: "6vw", margin: "0 12vw 0 13vw" }}>
                                        </span>
                                    </Link>
                                    <span className="iconfont icon-dianzan">
                                    </span> */}
                </div>
              </div>
            ))
          }
        </div>
        <input placeholder="       添加评论" style={{ width: '82%', marginTop: '1vh', height: '37px', borderColor: 'red', borderRadius: '15px', border: 'none' }} onChange={this.getContent} />
        <button style={{ width: '18%', height: '40px', borderBottomColor: 'gray', borderRadius: '30px', backgroundColor: '#3385FF', color: 'white', border: 'none' }} onClick={this.addItem} >发送</button>

        <p style={{ fontSize: 15, marginLeft: 5 }}>评论列表</p>
        <hr style={{ marginTop: -5 }}></hr>
        {/* <div style={{borderBottom:'1px soild black'}}></div> */}
        {
          this.state.todo.map((item,time) => (
            <div style={{ background: '#fff', color: 'black' }}>
              <div style={{ float: "left" }}>
                {/* <img src={this.state.pic[idx]} style={{ height: '5vh', width: '9vw', borderRadius: '50%', marginLeft: 15, marginTop: 9 }} /> */}
              </div>
              <p style={{ marginLeft: 25, fontSize: '2vh', lineHeight: 2.5, marginTop: 6 }}>{item.name}</p>
              <div style={{ marginLeft: 25, color: 'gray', fontSize: '3vw', marginTop: "-5vw" }}>{this.state.data[0].time}
              </div>
              <p style={{ marginLeft: 30, color: 'black', marginTop: 15, fontSize: 15, width: '90%' }}>{item.content}</p>
              <div style={{ width: '100%', height: '2vh', backgroundColor: 'white' }}>
              </div>
            </div>
          )
          )}
      </div>

    );
  }
}

