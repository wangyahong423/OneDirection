import React, { Component } from 'react'
import { NavBar, SearchBar, WingBlank, SegmentedControl } from 'antd-mobile';
import { HashRouter as Router, Route, Link } from 'react-router-dom';
import '../share.css'
import axios from 'axios';

export default class MaterialSharing extends Component {
    constructor() {
        super();
        this.state = {
            data: [],
            todo: [],
            start: false,
            name: "",
            defaultColor: false
        }
    }
    componentDidMount() {
        let url = `http://localhost:3005/file/list`;
        axios(url)
            .then((res) => {
                this.setState({
                    data: res.data
                })
            })
        let url1 = `http://localhost:3005/users/getName`;
        axios(url1)
            .then((res) => {
                console.log(this.state.name, res.data.name);
                this.setState({
                    name: res.data.name
                })
            })
        console.log(this.state.name)
        // let url2 = `http://localhost:3005/collect/list`;
        // axios(url2)
        //       .then((res) => {
        //         this.setState({
        //           todo: res.data
        //         })
        //       })
        //     this.state.data.map((item)=>{
        //         if(this.state.data.filepath==this.state.todo.filepath){
        //             this.setState({
        //                 defaultColor:true
        //             })
        //         }
        //     })

    }
    addCollect = (filepath, e) => {
        // console.log(this.state.start);
        this.setState({
            start: !this.state.start
        })
        console.log(this.state.start);
        if (this.state.start == true) {
            let url = `http://localhost:3005/collect/add?filepath=${filepath}&name=${this.state.name}`;
            axios(url)
                .then((res) => {
                })
            // window.location.reload();
    
        }
        else {
            
            let url1 = `http://localhost:3005/collect/delete?filepath=${filepath}&name=${this.state.name}`;
            axios(url1)
                .then((res) => {
                    if (res.err) {
                        alert('收藏失败');
                    } else {
                        console.log(1);
                        alert('收藏成功');
                    }
                })
        }
    }
    render() {
        return (
            <div>
                <NavBar
                    style={{ backgroundColor: '#37376F', color: '#fff', width: '100vw', position: 'fixed', top: '0', zIndex: 10, textAlign: 'center', height: '7vh' }}
                    leftContent={[
                        <Link to="/Share"><span style={{ fontSize: '17px', color: 'white' }} className="iconfont icon-ico_leftarrow"></span></Link>
                    ]}
                    rightContent={[
                        <form method="post" action="http://localhost:3005/file/addFile" encType="multipart/form-data">
                            <div style={{ height: "5vh", width: "5vh", fontSize: "3vh", marginTop: "2vh" }} className=" iconfont icon-shangchuanwenjian">
                                <input type="submit" value="上传" style={{ opacity: "0", position: "fixed", top: "1vh", left: "80vw" }}></input>
                            </div>
                            <div style={{ height: '8vh', width: '8vh', position: "fixed", top: "88%", left: "75vw" }}>
                                <span className="iconfont icon-jiahao" style={{ fontSize: "8vh", color: "#37376F" }}></span>
                                <input type="file" name="inputFile" multiple="multiple" style={{ opacity: 0, height: '8vh', width: '8vh', borderRadius: "50%", position: "fixed", top: "88%", left: "80vw", color: "black" }}></input>
                            </div>
                        </form>
                    ]}>
                    资料共享
                </NavBar>
                <div style={{ position: 'fixed', top: '0', width: "100vw" }}>
                    <WingBlank><div className="sub-title"></div></WingBlank>
                    <SearchBar placeholder="搜索" maxLength={8} />
                </div>
                <div style={{ marginTop: "13vh" }}>
                    {
                        this.state.data.map((item) => (
                            <div>
                                <div className="data1">
                                    <div style={{ float: "left" }}>
                                        <div className="iconfont icon-wenjian"></div>
                                        <div className="font1">
                                            <span>{item.filepath}</span><br />
                                            <span style={{ fontSize: "1vh" }}>{item.time}</span>&nbsp;&nbsp;
                                        <span style={{ fontSize: "1vh" }}>{item.name}</span>&nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <span className="iconfont icon-collection" onClick={this.addCollect.bind(this, (item.filepath))}></span><br />
                                </div>
                            </div>
                        ))
                    }
                </div>
            </div>
        )
    }
}
